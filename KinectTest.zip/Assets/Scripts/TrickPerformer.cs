﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TrickPerformer : MonoBehaviour
{
    private int _moveTime;
    private Renderer rend;

    public GestureReader gRead;
	// Use this for initialization
	void Start ()
    {
        _moveTime = 0;
        rend = this.GetComponentInChildren<Renderer>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        //recognition color
		if (gRead.focusid > 0 && rend.material.color == Color.white)
        {
            rend.material.color = Color.red;
        }

        //loss of recognition color
        if (gRead.focusid == 0 && rend.material.color == Color.red)
        {
            rend.material.color = Color.white;
        }

            if (gRead.shouldSit)
            {
                sitting();
            }

            if (gRead.shouldSpeak)
            {
                speaking();
            }

            if (gRead.shouldRollC)
            {
                rollingC();
            }

            if (gRead.shouldRollCC)
            {
                rollingCC();
            }
            if (gRead.shouldPlayDead)
            {
                playingDead();
            }

            if (_moveTime == 0)
            {
                Text temp = GameObject.Find("Text").GetComponent<Text>();
                temp.text = "";
            }
    }

    void sitting()
    {
        //Debug.Log("Sitting!");
        _moveTime++;

        if (_moveTime < 15)
        {
            gameObject.transform.position = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y - 0.1f, gameObject.transform.position.z);
        }
        else if (_moveTime > 65)
        {
            if (_moveTime > 80)
            {
                _moveTime = 0;
                gRead.shouldSit = false;
                gRead.singleCommand = false;
            }
            else
            {
                gameObject.transform.position = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y + 0.1f, gameObject.transform.position.z);
            }
        }
    }

    void speaking()
    {
        _moveTime++;
        if (_moveTime < 50)
        {
            rend.material.color = Color.blue;
        }
        else
        {
            rend.material.color = Color.red;
            _moveTime = 0;
            gRead.shouldSpeak = false;
            gRead.singleCommand = false;
        }
    }

    void rollingC()
    {
        _moveTime++;
        if (_moveTime < 73)
        {
            gameObject.transform.Rotate(Time.deltaTime * 0, 0, -5);
        }
        else
        {
            _moveTime = 0;
            gRead.shouldRollC = false;
            gRead.singleCommand = false;
        }
    }

    void rollingCC()
    {
        _moveTime++;
        if (_moveTime < 73)
        {
            gameObject.transform.Rotate(Time.deltaTime * 0, 0, 5);
        }
        else
        {
            _moveTime = 0;
            gRead.shouldRollCC = false;
            gRead.singleCommand = false;
        }
    }

    void playingDead()
    {
        _moveTime++;
        if (_moveTime < 100)
        {
            rend.material.color = Color.green;
            Text temp = this.gameObject.GetComponentInChildren<Text>();
            //Text temp = GameObject.Find("ZText").GetComponent<Text>();
            temp.text = "Brains?";
        }
        else
        {
            Text temp = GameObject.Find("ZText").GetComponent<Text>();
            temp.text = "";
            rend.material.color = Color.red;
            _moveTime = 0;
            gRead.shouldPlayDead = false;
            gRead.singleCommand = false;
        }
    }
}
