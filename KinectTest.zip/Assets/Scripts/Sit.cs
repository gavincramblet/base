﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;


public class Sit : Gesture
{
    public override void Start()
    {
        Debug.Log("Entering sit start function");
        IGesturePart sit1 = new SitPart1();
        IGesturePart sit2 = new SitPart2();

        _parts = new IGesturePart[]
        {
            sit1,
            sit2
        };

        GestureType = "Sit";
    }

}

public class SitPart1 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xleeway = 0.1f;
    public float yleeway = 0.2f;
    public float startY = 0.15f;

    public GesturePartResult PUpdate(Body body)
    {

        // Hand above elbow
        if (body.Joints[JointType.HandRight].Position.Y >
            body.Joints[JointType.ElbowRight].Position.Y + startY &&
            body.Joints[JointType.HandLeft].Position.Y >
            body.Joints[JointType.ElbowLeft].Position.Y + startY)
        {
            //Hand aligned with elbow
            if (Mathf.Abs(body.Joints[JointType.HandRight].Position.X - 
                body.Joints[JointType.ElbowRight].Position.X) < xleeway &&
                Mathf.Abs(body.Joints[JointType.HandLeft].Position.X -
                body.Joints[JointType.ElbowLeft].Position.X) < xleeway)
            {
                return GesturePartResult.Succeeded;
            }

        }
        return GesturePartResult.Failed;
    }

    public List<float> getPrev() { return null; }
    public void setPrev(List<float> prevs) { }
}

public class SitPart2 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xleeway = 0.15f;
    public float yleeway = 0.039f;

    public GesturePartResult PUpdate(Body body)
    {
        float diff1 = body.Joints[JointType.HandRight].Position.Y -
                body.Joints[JointType.ElbowRight].Position.Y;
        float diff2 = Mathf.Abs(body.Joints[JointType.HandRight].Position.X -
                body.Joints[JointType.ElbowRight].Position.X);
        float diff3 = body.Joints[JointType.HandLeft].Position.Y -
                body.Joints[JointType.ElbowLeft].Position.Y;
        float diff4 = Mathf.Abs(body.Joints[JointType.HandLeft].Position.X -
                body.Joints[JointType.ElbowLeft].Position.X);

        // Hand level with elbow
        if ((Mathf.Abs(diff1) < yleeway || diff1 < 0) && (Mathf.Abs(diff3) < yleeway || diff3 < 0))
        {
            //Hand aligned with elbow
            if (diff2 < xleeway && diff4 < xleeway)
            {
                Debug.Log("Diff1: " + diff1 + " Diff2: " + diff2 + " Diff3: " + diff3 + " Diff4: " + diff4);
                return GesturePartResult.Succeeded;
            }

        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return null; }
    public void setPrev(List<float> prevs) { }
}
