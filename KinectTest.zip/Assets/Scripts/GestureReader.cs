﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;

public class GestureReader : MonoBehaviour
{
    //define gestures
    Gesture _sitGesture = new Sit();
    Gesture _speakGesture = new Speak();
    Gesture _rollCGesture = new RollClockwise();
    Gesture _rollCCGesture = new RollCounterClockwise();
    Gesture _playDeadGesture = new PlayDead();

    //variables to detect body of user
    [HideInInspector]
    public ulong focusid = 0;
    public Body myBody;
    public BodyHandler bh;
    private bool bodySetup = true;

    [HideInInspector]
    public bool shouldSit, shouldSpeak, shouldRollC, shouldRollCC, shouldPlayDead, singleCommand = false;

    public int bodyIndex;

    // Use this for initialization
    void Start ()
    {
        _sitGesture.Start();
        _speakGesture.Start();
        _rollCGesture.Start();
        _rollCCGesture.Start();
        _playDeadGesture.Start();
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (bh.players[bodyIndex] == null)
        {
            focusid = 0;
        }
        else
        {
            if (bh.players[bodyIndex].IsTracked)
            {
                if (bodySetup)
                {
                    bodySetup = false;
                    focusid = bh.focusid1;

                    //now that we have a body to listen to, start listning for gestures
                    _sitGesture.GestureRecognized.AddListener(Gesture_GestureRecognized);
                    _speakGesture.GestureRecognized.AddListener(Gesture_GestureRecognized);
                    _rollCGesture.GestureRecognized.AddListener(Gesture_GestureRecognized);
                    _rollCCGesture.GestureRecognized.AddListener(Gesture_GestureRecognized);
                    _playDeadGesture.GestureRecognized.AddListener(Gesture_GestureRecognized);

                }
                else
                {

                _sitGesture.PUpdate(bh.players[bodyIndex]);
                _speakGesture.PUpdate(bh.players[bodyIndex]);
                _rollCGesture.PUpdate(bh.players[bodyIndex]);
                _rollCCGesture.PUpdate(bh.players[bodyIndex]);
                _playDeadGesture.PUpdate(bh.players[bodyIndex]);

                /*Text temp = GameObject.Find("Text").GetComponent<Text>();
                temp.text = String.Format("{0:0.000}", body.Joints[JointType.HandRight].Position.X) + ", \r\n" 
                        + String.Format("{0:0.000}", body.Joints[JointType.HandRight].Position.Y) + ", \r\n" 
                        + String.Format("{0:0.000}", body.Joints[JointType.ElbowRight].Position.Y) + ", \r\n"
                        + String.Format("{0:0.000}", body.Joints[JointType.HandLeft].Position.X) + ", \r\n"
                        + String.Format("{0:0.000}", body.Joints[JointType.HandLeft].Position.Y) + ", \r\n"
                        + String.Format("{0:0.000}", body.Joints[JointType.ElbowLeft].Position.Y);*/

                }
            }
        }
    }

    void Gesture_GestureRecognized(string type)//<string>(object sender, EventArgs e)
    {
        //currently this is just displaying the command as text
        //eventually we'll hook this up to a puppy who can execute the commands
        Debug.Log(type);
        //Text temp = GameObject.Find("Text").GetComponent<Text>();
        //temp.text = type;

        if (!singleCommand)
        {
            switch (type)
            {
                case "Sit":
                    shouldSit = true;
                    singleCommand = true;
                    break;
                case "Speak":
                    shouldSpeak = true;
                    singleCommand = true;
                    break;
                case "Roll Clockwise":
                    shouldRollC = true;
                    singleCommand = true;
                    break;
                case "Roll Counter Clockwise":
                    shouldRollCC = true;
                    singleCommand = true;
                    break;
                case "Play Dead":
                    shouldPlayDead = true;
                    singleCommand = true;
                    break;
            }
        }
    }
}
