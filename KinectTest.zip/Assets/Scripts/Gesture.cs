﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;

//probably not necessary but simplifying things for now
public class StringEvent : UnityEvent <string> { }

public abstract class Gesture
{
    public StringEvent GestureRecognized = new StringEvent();

    //stores the parts to each gesture
    public IGesturePart[] _parts;

    //time the user has to execute the command
    //might adjust this for longer commands
    public int timeToExecute = 15;

    //the message sent along with the event; will almost always be replaced by specific gesture
    public string GestureType = "Gesture";

    int _currentPart = 0;
    int _frameCount = 0;
    
    //a list of previous coordinates; used for some commands who need to see where the previous part was
    private List<float> _prevs = null;
    
    public virtual void Start()
    {
        //most gestures are going to overwrite this start function
        Debug.Log("Entering default start function");
    }

    public void PUpdate(Body body)
    {
        if (_parts == null)
        {
            Debug.Log("Parts array not initialized");
        }
        else
        {
            //if we have an array of previous coordinates, send it in
            _parts[_currentPart].setPrev(_prevs);

            //check to see if the next gesture part has been accomplished
            GesturePartResult result = _parts[_currentPart].PUpdate(body);
            
            if (result == GesturePartResult.Succeeded)
            {
                if (_currentPart + 1 < _parts.Length) //gesture sequence not finished
                {
                    //store previous gesture part's coordinates, if applicable
                    _prevs = _parts[_currentPart].getPrev();

                    //prepare for next part
                    _currentPart++;
                    _frameCount = 0;
                }
                else
                {
                    //Gesture is complete
                    Debug.Log("Surpassed Parts Length");
                    if (GestureRecognized != null)
                    {
                        Debug.Log("Gesture Recognized from body " + body.TrackingId);
                        GestureRecognized.Invoke(GestureType);
                        Reset();
                    }
                    else //this should only happen if the event handler isn't set up correctly
                    {
                        Debug.Log("GestureRecognized is null");
                    }
                }
            }
            else if (result == GesturePartResult.Failed || _frameCount >= timeToExecute)
            {
                //if the user exceeds the gesture time limit, start over
                Reset();
            }
            else
            {
                _frameCount++;
            }
        }
    }

    public void Reset()
    {
        _prevs = null;
        _currentPart = 0;
        _frameCount = 0;
    }

    
}
