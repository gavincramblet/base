﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;

public class BodyHandler : MonoBehaviour
{

    //variables to detect body of user
    public BodySourceManager bodyManager;
    private Body[] _bodies;
    public ulong focusid1 = 0;
    public ulong focusid2 = 0;
    public bool body1Found = false;
    public Body[] players;

    // Use this for initialization
    void Start ()
    {
        players = new Body[2];
	}

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }

        if (bodyManager == null)
        {
            return;
        }

        _bodies = bodyManager.GetData();

        if (_bodies == null)
        {
            focusid1 = 0;
            return;
        }

        foreach (var body in _bodies)
        {
            if (body == null)
            {
                //existing body has left frame
                //Debug.Log("Body is null again");
                continue;
            }

            if (body.IsTracked)
            {
                if (focusid1 == 0)
                {
                    //first body discovered
                    Debug.Log("Body 1 found " + body.TrackingId);
                    body1Found = true;
                    //focusid1 = body.TrackingId;
                    players[0] = body;
                }
                else if (focusid2 == 0 && body.TrackingId != focusid1)
                {
                    //second body discovered
                    Debug.Log("Body 2 found " + body.TrackingId);
                    //focusid2 = body.TrackingId;
                    players[1] = body;
                }
                else
                {
                    if (body.TrackingId == focusid1 || body.TrackingId == focusid2)
                    {
                        //Debug.Log("Body refound");
                        body1Found = true;
                    }
                    else
                    {
                        //Debug.Log("ignore " + body.TrackingId);
                        //ignore other _bodies;
                    }
                }
            }
        }

        //Debug.Log("bodyFound:" + body1Found);

        if (body1Found == false && (focusid1 != 0 || focusid2 != 0))
        {
            //original body list; reset focus so another can be found
            Debug.Log("focusid is null again");
            focusid1 = 0;
            focusid2 = 0;
            players[0] = null;
            players[1] = null;
        }
        else
        {
            body1Found = false;
        }
    }
}
