﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;


public class Speak : Gesture
{
    public override void Start()
    {
        Debug.Log("Entering speak start function");
        IGesturePart speak1 = new SpeakPart1();
        IGesturePart speak2 = new SpeakPart2();

        _parts = new IGesturePart[]
        {
            speak1,
            speak2
        };

        GestureType = "Speak";
    }

}

public class SpeakPart1 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xleeway = 0.3f;
    public float yleeway = 0.3f;
    public float zleeway = 0.3f;

    public GesturePartResult PUpdate(Body body)
    {
        float diffX = Mathf.Abs(body.Joints[JointType.HandRight].Position.X -
        body.Joints[JointType.HandLeft].Position.X);

        float diffY = Mathf.Abs(body.Joints[JointType.HandRight].Position.Y -
        body.Joints[JointType.HandLeft].Position.Y);

        float diffZ = Mathf.Abs(body.Joints[JointType.HandRight].Position.Z -
        body.Joints[JointType.HandLeft].Position.Z);

        // Hands aligned with each other
        if (diffX < xleeway && diffY < yleeway && diffZ < zleeway)
        {
                return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Failed;
    }

    public List<float> getPrev() { return null; }
    public void setPrev(List<float> prevs) { }
}

public class SpeakPart2 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xleeway = 0.15f;

    public GesturePartResult PUpdate(Body body)
    {
        /*float diff1 = Mathf.Abs(body.Joints[JointType.ElbowLeft].Position.Y -
                body.Joints[JointType.ElbowRight].Position.Y);
        float diff2 = Mathf.Abs(body.Joints[JointType.ElbowLeft].Position.X -
                body.Joints[JointType.ElbowRight].Position.X);*/
        float diff3 = Mathf.Abs(body.Joints[JointType.HandLeft].Position.Y -
                body.Joints[JointType.HandRight].Position.Y);
        float diff4 = Mathf.Abs(body.Joints[JointType.HandLeft].Position.X -
                body.Joints[JointType.HandRight].Position.X);

        // Hands spread
        if (diff3 > 0.4 && diff4 < xleeway)
        {
            //Elbows Aligned
            /*if (diff1 < yleeway && diff2 < xleeway)
            {
                Debug.Log("Diff1: " + diff1 + " Diff2: " + diff2 + " Diff3: " + diff3 + " Diff4: " + diff4);*/
                return GesturePartResult.Succeeded;
            //}

        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return null; }
    public void setPrev(List<float> prevs) { }
}
