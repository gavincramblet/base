﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;

public class RollClockwise : Gesture
{

    public override void Start()
    {
        Debug.Log("Entering roll clockwise start function");
        IGesturePart part1 = new RollCPart1();
        IGesturePart part2 = new RollCPart2();
        IGesturePart part3 = new RollCPart3();
        IGesturePart part4 = new RollCPart4();
        IGesturePart part5 = new RollCPart5();

        _parts = new IGesturePart[]
        {
            part1,
            part2,
            part3,
            part4,
            part5
        };

        GestureType = "Roll Clockwise";
        timeToExecute = 30;
    }

}

public class RollCPart1 : IGesturePart
{
    float xSeparation = 0.1f;
    private List<float> _partPrevs;
    public GesturePartResult PUpdate(Body body)
    {
        float Xdiff = body.Joints[JointType.ElbowRight].Position.X - body.Joints[JointType.HandRight].Position.X;

        //start from the 'right hand to the left of right elbow' position
        if (Xdiff > xSeparation)
        {

            List<float> prevs = new List<float>
            {
                body.Joints[JointType.HandRight].Position.X,
                body.Joints[JointType.HandLeft].Position.Y
            };

            //Debug.Log("Part 1");
            setPrev(prevs);

            return GesturePartResult.Succeeded;
        }

        return GesturePartResult.Failed;
    }

    public List<float> getPrev() { return _partPrevs; }
    public void setPrev(List<float> prevs) { _partPrevs = prevs; }
}

public class RollCPart2 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = 0.05f;
    public float ySeparation = 0.05f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand above and to the right
        if (Xdiff > xSeparation && Ydiff > ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX, newY
            };
            //Debug.Log("Part 1: " + prevX + ", " + prevY + " Part 2: " + prevs[0] + ", " + prevs[1] +
            //    "Part 2x: " + newX + ", " + newY );
            setPrev(prevs);

            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}

public class RollCPart3 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = 0.10f;
    public float ySeparation = -0.10f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand below and to the right
        if (Xdiff > xSeparation && Ydiff < ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX,
                newY
            };

            setPrev(prevs);
            //Debug.Log("Part 3" + prevs[0] + ", " + prevs[1]);
            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}

public class RollCPart4 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = -0.10f;
    public float ySeparation = -0.10f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand below and to the Left
        if (Xdiff < xSeparation && Ydiff < ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX,
                newY
            };

            setPrev(prevs);
            //Debug.Log("Part 4" + prevs[0] + ", " + prevs[1]);
            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}

public class RollCPart5 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = -0.10f;
    public float ySeparation = 0.10f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand above and to the left
        if (Xdiff < xSeparation && Ydiff > ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX,
                newY
            };
            //Debug.Log("Part 5");
            setPrev(prevs);

            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}


