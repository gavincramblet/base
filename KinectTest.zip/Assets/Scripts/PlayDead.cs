﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;


public class PlayDead : Gesture
{
    public override void Start()
    {
        Debug.Log("Entering play dead start function");
        IGesturePart part1 = new deadPart1();

        _parts = new IGesturePart[]
        {
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1,
            part1
        };

        GestureType = "Play Dead";
        timeToExecute = 50;
    }

}

public class deadPart1 : IGesturePart
{
    float xSeparation = 0.15f;
    float ySeparation = 0.15f;
    private List<float> _partPrevs;
    public GesturePartResult PUpdate(Body body)
    {
        float X1diff = Mathf.Abs(body.Joints[JointType.ElbowRight].Position.X - body.Joints[JointType.HandRight].Position.X);
        float X2diff = Mathf.Abs(body.Joints[JointType.ElbowRight].Position.X - body.Joints[JointType.ShoulderRight].Position.X);
        float X3diff = Mathf.Abs(body.Joints[JointType.ElbowLeft].Position.X - body.Joints[JointType.HandLeft].Position.X);
        float X4diff = Mathf.Abs(body.Joints[JointType.ElbowLeft].Position.X - body.Joints[JointType.ShoulderLeft].Position.X);
        float Y1diff = Mathf.Abs(body.Joints[JointType.ElbowRight].Position.Y - body.Joints[JointType.HandRight].Position.Y);
        float Y2diff = Mathf.Abs(body.Joints[JointType.ElbowRight].Position.Y - body.Joints[JointType.ShoulderRight].Position.Y);
        float Y3diff = Mathf.Abs(body.Joints[JointType.ElbowLeft].Position.Y - body.Joints[JointType.HandLeft].Position.Y);
        float Y4diff = Mathf.Abs(body.Joints[JointType.ElbowLeft].Position.Y - body.Joints[JointType.ShoulderLeft].Position.Y);

        //Debug.Log(X1diff + ", " + X2diff + ", " + X3diff + ", " + X4diff + ", " + Y1diff + ", " + Y2diff + ", " + Y3diff + ", " + Y4diff);

        //start from the 'right hand to the left of right elbow' position
        if (X1diff < xSeparation && X2diff < xSeparation && X3diff < xSeparation && X4diff < xSeparation &&
            Y1diff < ySeparation && Y2diff < ySeparation && Y3diff < ySeparation && Y4diff < ySeparation)
        {
            return GesturePartResult.Succeeded;
        }

        return GesturePartResult.Failed;
    }

    public List<float> getPrev() { return _partPrevs; }
    public void setPrev(List<float> prevs) { _partPrevs = prevs; }
}
