﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;

public class RollCounterClockwise : Gesture
{

    public override void Start()
    {
        Debug.Log("Entering roll counter clockwise start function");
        IGesturePart part1 = new RollCCPart1();
        IGesturePart part2 = new RollCCPart2();
        IGesturePart part3 = new RollCCPart3();
        IGesturePart part4 = new RollCCPart4();
        IGesturePart part5 = new RollCCPart5();

        _parts = new IGesturePart[]
        {
            part1,
            part2,
            part3,
            part4,
            part5
        };

        GestureType = "Roll Counter Clockwise";
        timeToExecute = 20;
    }

}

public class RollCCPart1 : IGesturePart
{
    float xSeparation = 0.1f;
    private List<float> _partPrevs;
    public GesturePartResult PUpdate(Body body)
    {
        float Xdiff = body.Joints[JointType.ElbowRight].Position.X - body.Joints[JointType.HandRight].Position.X;

        //start from the 'right hand to the left of right elbow' position
        if (Xdiff > xSeparation)
        {

            //since this is a start point gesture, we don't really need to check much
            List<float> prevs = new List<float>
            {
                body.Joints[JointType.HandRight].Position.X,
                body.Joints[JointType.HandLeft].Position.Y
            };

            //Debug.Log("Part C1");
            setPrev(prevs);

            return GesturePartResult.Succeeded;
        }

        return GesturePartResult.Failed;
    }

    public List<float> getPrev() { return _partPrevs; }
    public void setPrev(List<float> prevs) { _partPrevs = prevs; }
}

public class RollCCPart2 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = 0.05f;
    public float ySeparation = -0.05f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand below and to the right
        if (Xdiff > xSeparation && Ydiff < ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX,
                newY
            };
            //Debug.Log("Part C2");
            setPrev(prevs);

            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}

public class RollCCPart3 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = 0.10f;
    public float ySeparation = 0.10f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand above and to the right
        if (Xdiff > xSeparation && Ydiff > ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX,
                newY
            };

            setPrev(prevs);
            //Debug.Log("Part C3");
            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}

public class RollCCPart4 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = -0.10f;
    public float ySeparation = 0.10f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand above and to the Left
        if (Xdiff < xSeparation && Ydiff > ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX,
                newY
            };

            setPrev(prevs);
            //Debug.Log("Part C4");
            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}

public class RollCCPart5 : IGesturePart
{
    //these will need to be calibrated to avoid false positives and frustrating negatives
    public float xSeparation = -0.10f;
    public float ySeparation = -0.10f;
    private List<float> partPrevs;

    public GesturePartResult PUpdate(Body body)
    {
        float prevX = partPrevs[0];
        float prevY = partPrevs[1];

        float newX = body.Joints[JointType.HandRight].Position.X;
        float newY = body.Joints[JointType.HandRight].Position.Y;

        float Xdiff = newX - prevX;
        float Ydiff = newY - prevY;


        // Hand below and to the left
        if (Xdiff < xSeparation && Ydiff < ySeparation)
        {
            //Make sure to send in these valid coordinates first
            List<float> prevs = new List<float>
            {
                newX,
                newY
            };
            //Debug.Log("Part C5");
            setPrev(prevs);

            return GesturePartResult.Succeeded;
        }
        return GesturePartResult.Unknown;
    }

    public List<float> getPrev() { return partPrevs; }
    public void setPrev(List<float> prevs) { partPrevs = prevs; }
}
