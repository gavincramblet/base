﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Windows.Kinect;
using KJoint = Windows.Kinect.Joint;

//May need an 'unknown' state for later, so we're not using a boolean
public enum GesturePartResult
{
    Failed,
    Unknown,
    Succeeded
}

public interface IGesturePart
{
    GesturePartResult PUpdate(Body body); //Check if this gesture part is accomplished
    List<float> getPrev(); //get coordinates of previous gesture
    void setPrev(List<float> prevs); //set coordinates for this gesture
}
